
const data = {
  produtos: [
    { id: 1, nome: "Camisa Real Madrid Home 25/26", preco: 349.90, categoria: "Camisas", marca: "Adidas", tamanhos: ["P", "M", "G", "GG"], destaque: true, emEstoque: true,
      imagem: "assets/img/real.webp",
      descricao: "Camisa titular oficial do Real Madrid com tecnologia de alta respirabilidade.",
      conteudo: "Tecido leve com ventilação nas costas e escudo bordado. Ideal para torcer nos jogos ou usar no dia a dia.",
      fotos: [
        { titulo: "Frente da camisa", arquivo: "assets/img/real.webp" },
        { titulo: "Detalhe do escudo", arquivo: "assets/img/real-2.webp" },
        { titulo: "Costas da camisa", arquivo: "assets/img/real-3.webp" }
      ] },
    { id: 2, nome: "Camisa Barcelona Home 25/26", preco: 349.90, categoria: "Camisas", marca: "Nike", tamanhos: ["P", "M", "G", "GG"], destaque: true, emEstoque: true,
      imagem: "assets/img/barca.webp",
      descricao: "Camisa oficial titular do Barcelona com design clássico em blaugrana.",
      conteudo: "Listras azul e grená com acabamento Dri-FIT que mantém o corpo seco durante o jogo.",
      fotos: [
        { titulo: "Frente da camisa", arquivo: "assets/img/barca.webp" },
        { titulo: "Detalhe do tecido", arquivo: "assets/img/barca-2.webp" },
        { titulo: "Costas da camisa", arquivo: "assets/img/barca-3.webp" }
      ] },
    { id: 3, nome: "Casaco de Inverno Manchester City", preco: 459.90, categoria: "Casacos", marca: "Puma", tamanhos: ["M", "G", "GG"], destaque: false, emEstoque: false,
      imagem: "assets/img/manchester.jpg",
      descricao: "Casaco forrado oficial do Manchester City para dias frios.",
      conteudo: "Forro térmico, capuz ajustável e bolsos com zíper. Produto temporariamente indisponível.",
      fotos: [
        { titulo: "Visão geral", arquivo: "assets/img/manchester.jpg" },
        { titulo: "Detalhe do capuz", arquivo: "assets/img/manchester-2.jpg" }
      ] },
    { id: 4, nome: "Camisa Seleção Brasileira 25/26", preco: 379.90, categoria: "Camisas", marca: "Nike", tamanhos: ["P", "M", "G", "GG"], destaque: true, emEstoque: true,
      imagem: "assets/img/seleca.webp",
      descricao: "A tradicional amarelinha da Seleção Brasileira.",
      conteudo: "Amarelo vibrante com gola verde e escudo da CBF. Corte moderno e tecido de secagem rápida.",
      fotos: [
        { titulo: "Frente da camisa", arquivo: "assets/img/seleca.webp" },
        { titulo: "Detalhe da gola", arquivo: "assets/img/seleca-2.webp" },
        { titulo: "Costas da camisa", arquivo: "assets/img/seleca-3.webp" }
      ] },
    { id: 5, nome: "Casaco Corta-Vento do Flamengo", preco: 299.90, categoria: "Casacos", marca: "Adidas", tamanhos: ["P", "M", "G"], destaque: false, emEstoque: true,
      imagem: "assets/img/fla.webp",
      descricao: "Jaqueta corta-vento oficial licenciada do Rubro-Negro.",
      conteudo: "Jaqueta leve e impermeável, perfeita para chuva e treinos ao ar livre, com listras rubro-negras.",
      fotos: [
        { titulo: "Visão geral", arquivo: "assets/img/fla.webp" },
        { titulo: "Detalhe do zíper", arquivo: "assets/img/fla-2.webp" }
      ] },
    { id: 6, nome: "Moletom com Capuz Palmeiras", preco: 329.00, categoria: "Casacos", marca: "Puma", tamanhos: ["M", "G", "GG"], destaque: true, emEstoque: true,
      imagem: "assets/img/palme.jpg",
      descricao: "Moletom confortável com o escudo e cores do Verdão.",
      conteudo: "Moletom felpudo por dentro, capuz com cordão e bolso canguru. Para quem leva o Verdão para qualquer lugar.",
      fotos: [
        { titulo: "Visão geral", arquivo: "assets/img/palme.jpg" },
        { titulo: "Detalhe do escudo", arquivo: "assets/img/palme-2.jpg" }
      ] }
  ]
};

function formatPrice(preco) {
  return `R$ ${preco.toFixed(2).replace(".", ",")}`;
}

function imgFallback(produto) {
  return `onerror="this.onerror=null;this.src='${produto.imagem}'"`;
}

function renderCarousel() {
  const destaques = data.produtos.filter(p => p.destaque);
  const inner = document.querySelector("#carrossel-itens");
  const indicators = document.querySelector("#carrossel-indicadores");

  destaques.forEach((p, i) => {
    const ativo = i === 0 ? "active" : "";
    indicators.innerHTML += `<button type="button" data-bs-target="#carrosselDestaques" data-bs-slide-to="${i}" class="${ativo}" aria-label="Slide ${i + 1}"></button>`;
    inner.innerHTML += `
      <div class="carousel-item ${ativo}">
        <div class="slide">
          <a href="detalhes.html?id=${p.id}"><img src="${p.imagem}" alt="${p.nome}"></a>
          <div>
            <h3><a href="detalhes.html?id=${p.id}" class="text-white text-decoration-none">${p.nome}</a></h3>
            <p>${p.descricao}</p>
            <p class="fw-bold fs-5">${formatPrice(p.preco)}</p>
            <a href="detalhes.html?id=${p.id}" class="btn btn-ver">Ver detalhes</a>
          </div>
        </div>
      </div>`;
  });
}

function createProductCard(produto) {
  const col = document.createElement("div");
  col.className = "col-12 col-sm-6 col-lg-4 col-xl-3";
  col.innerHTML = `
    <div class="card card-produto" data-id="${produto.id}">
      <a href="detalhes.html?id=${produto.id}"><img src="${produto.imagem}" alt="${produto.nome}"></a>
      <div class="card-body d-flex flex-column">
        <h3 class="card-title"><a href="detalhes.html?id=${produto.id}">${produto.nome}</a></h3>
        <p class="preco mb-1">${formatPrice(produto.preco)}</p>
        <p class="mb-3"><span class="badge text-bg-secondary">${produto.categoria}</span></p>
        <div class="mt-auto d-flex gap-2">
          <a href="detalhes.html?id=${produto.id}" class="btn btn-sm btn-detalhes">Ver detalhes</a>
          <button class="btn btn-sm btn-outline-warning btn-highlight">Destacar</button>
        </div>
      </div>
    </div>`;

  col.querySelector(".btn-highlight").addEventListener("click", () => {
    col.querySelector(".card-produto").classList.toggle("highlight");
  });
  return col;
}

function renderProducts(produtos) {
  const list = document.getElementById("product-list");
  list.innerHTML = "";
  if (produtos.length === 0) {
    list.innerHTML = `<p class="text-center">Nenhum produto encontrado. Tente outro nome ou categoria.</p>`;
    return;
  }
  produtos.forEach(p => list.appendChild(createProductCard(p)));
}

function renderCategories() {
  const select = document.querySelector("#category");
  [...new Set(data.produtos.map(p => p.categoria))].forEach(cat => {
    const option = document.createElement("option");
    option.value = cat;
    option.textContent = cat;
    select.appendChild(option);
  });
}

function filterProducts() {
  const texto = document.querySelector("#search").value.toLowerCase();
  const categoria = document.querySelector("#category").value;
  renderProducts(data.produtos.filter(p =>
    p.nome.toLowerCase().includes(texto) &&
    (categoria === "Todas" || p.categoria === categoria)
  ));
}

function initHome() {
  renderCarousel();
  renderCategories();
  renderProducts(data.produtos);
  document.querySelector("#search").addEventListener("input", filterProducts);
  document.querySelector("#category").addEventListener("change", filterProducts);
  document.querySelector("#btnRender").addEventListener("click", () => {
    document.querySelector("#search").value = "";
    document.querySelector("#category").value = "Todas";
    renderProducts(data.produtos);
  });
}

function initDetalhes() {
  const id = Number(new URLSearchParams(window.location.search).get("id"));
  const p = data.produtos.find(item => item.id === id);
  const box = document.getElementById("detalhes-produto");

  if (!p) {
    box.innerHTML = `<div class="alert alert-warning">Produto não encontrado. <a href="index.html">Voltar ao catálogo</a>.</div>`;
    document.getElementById("t-fotos").parentElement.style.display = "none";
    return;
  }

  document.title = p.nome;
  const status = p.emEstoque
    ? `<span class="badge text-bg-success">Em estoque</span>`
    : `<span class="badge text-bg-danger">Indisponível</span>`;

  box.innerHTML = `
    <div class="row g-4">
      <div class="col-12 col-md-5">
        <img class="detalhe-img" src="${p.imagem}" alt="${p.nome}">
      </div>
      <div class="col-12 col-md-7">
        <h3 class="display-6 fw-bold">${p.nome}</h3>
        <p class="lead">${p.descricao}</p>
        <p>${p.conteudo}</p>
        <ul class="ficha">
          <li><span>Preço</span><span class="preco">${formatPrice(p.preco)}</span></li>
          <li><span>Categoria</span><span>${p.categoria}</span></li>
          <li><span>Marca</span><span>${p.marca}</span></li>
          <li><span>Tamanhos</span><span>${p.tamanhos.join(", ")}</span></li>
          <li><span>Disponibilidade</span>${status}</li>
        </ul>
      </div>
    </div>`;

  const fotos = document.getElementById("fotos-produto");
  p.fotos.forEach(f => {
    fotos.innerHTML += `
      <div class="col-12 col-sm-6 col-lg-4">
        <figure class="foto-card m-0">
          <img src="${f.arquivo}" alt="${f.titulo}" ${imgFallback(p)}>
          <p>${f.titulo}</p>
        </figure>
      </div>`;
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("product-list")) initHome();
  if (document.getElementById("detalhes-produto")) initDetalhes();
});
